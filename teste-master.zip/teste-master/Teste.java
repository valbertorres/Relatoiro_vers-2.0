public class{

	public void imprimir(){
	System.out.println("teste");
	} 

}