package com.intersys.relatorio.fabricaconexao;

public class ChaveTO {

	private String tipoVenda;
	private long chave;

	public String getTipoVenda() {
		return tipoVenda;
	}

	public void setTipoVenda(String tipoVenda) {
		this.tipoVenda = tipoVenda;
	}

	public long getChave() {
		return chave;
	}

	public void setChave(long chave) {
		this.chave = chave;
	}

}
