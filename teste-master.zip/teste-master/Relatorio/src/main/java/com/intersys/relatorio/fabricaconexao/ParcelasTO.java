package com.intersys.relatorio.fabricaconexao;

public class ParcelasTO {

	private int parcelas;

	public int getParcelas() {
		return parcelas;
	}

	public void setParcelas(int parcelas) {
		this.parcelas = parcelas;
	}

}
